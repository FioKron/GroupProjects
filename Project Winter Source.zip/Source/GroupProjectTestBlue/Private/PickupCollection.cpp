// Fill out your copyright notice in the Description page of Project Settings.

#include "GroupProjectTestBlue.h"
#include "PickupCollection.h"


// The primary constructor for this class:
APickupCollection::APickupCollection()
{
 	// Allow ticking for now:
	PrimaryActorTick.bCanEverTick = true;
}

// To add Pickups:
void APickupCollection::AddPickupToCollection(APickup* PickupToAdd)
{
	if (PickupToAdd != NULL)
	{
		PrimaryCollectionComponent.Add(PickupToAdd);
	}
}

// For removing Pickups:
APickup* APickupCollection::RemovePickupFromCollection(FString PickupToRemove)
{
	// The return value
	APickup* PickupRemoved = CreateAbstractDefaultSubobject<APickup>(TEXT("PickupRemoved"));

	// Check each value in the array:
	for (int32 CurrentPickupIndex = 0; CurrentPickupIndex < PrimaryCollectionComponent.Num(); CurrentPickupIndex++)
	{
		if (PrimaryCollectionComponent[CurrentPickupIndex]->GetPickupID() == PickupToRemove)
		{
			PickupRemoved = PrimaryCollectionComponent[CurrentPickupIndex];

			PrimaryCollectionComponent.RemoveAt(CurrentPickupIndex);
		}
	}

	return PickupRemoved;
}
