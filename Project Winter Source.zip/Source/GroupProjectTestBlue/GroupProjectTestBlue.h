// Copyright 1998-2015 Epic Games, Inc. All Rights Reserved.

#ifndef __GROUPPROJECTTESTBLUE_H__
#define __GROUPPROJECTTESTBLUE_H__

#include "EngineMinimal.h"

#endif
