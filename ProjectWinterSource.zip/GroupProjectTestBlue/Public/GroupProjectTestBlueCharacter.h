// Copyright 1998-2015 Epic Games, Inc. All Rights Reserved.
#pragma once
#include "GameFramework/Character.h"
#include "GroupProjectTestBlueCharacter.generated.h"

UCLASS(config=Game)
class AGroupProjectTestBlueCharacter : public ACharacter
{
	GENERATED_BODY()

};

